Copy the AccelStepper folder into Arduino\libraries before compiling

Note:

Trademarks
AccelStepper is a trademark of AirSpayce Pty Ltd. The AccelStepper mark was first used on April 26 2010 for international trade, and is used only in relation to motor control hardware and software. It is not to be confused with any other similar marks covering other goods and services.

Copyright
This software is Copyright (C) 2010-2018 Mike McCauley. Use is subject to license conditions. The main licensing options available are GPL V3 or Commercial:

Open Source Licensing GPL V3
This is the appropriate option if you want to share the source code of your application with everyone you distribute it to, and you also want to give them the right to share who uses it. If you wish to use this software under Open Source Licensing, you must contribute all your source code to the open source community in accordance with the GPL Version 23 when your application is distributed. See https://www.gnu.org/licenses/gpl-3.0.html
Commercial Licensing
This is the appropriate option if you are creating proprietary applications and you are not prepared to distribute and share the source code of your application. To purchase a commercial license, contact info@airspayce.com

More information is available at:
https://www.airspayce.com/mikem/arduino/AccelStepper/